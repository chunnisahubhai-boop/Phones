# Phone App — Android Project (Real, Native)

यह एक असली Android Studio project है — Kotlin + Jetpack Compose में बना।
Website prototype के उलट, इसमें calling, contacts, WhatsApp सब **असली Android system APIs** से जुड़े हैं।

## कैसे चलाएं

1. **Android Studio** install करें (Giraffe/Koala या नया वर्शन) — https://developer.android.com/studio
2. Android Studio खोलें → **Open** → इस `PhoneApp` फ़ोल्डर को चुनें
3. पहली बार खुलने पर Gradle sync अपने आप शुरू होगा (internet चाहिए) — थोड़ी देर लगेगी
4. अपने फोन में **USB Debugging** ऑन करें (Settings → About Phone → 7 बार "Build Number" दबाएं → Developer Options → USB Debugging)
5. फोन को USB से जोड़ें → ऊपर हरे ▶ Run बटन को दबाएं
6. ऐप खुलते ही Contacts Permission माँगेगा — अनुमति दें

## अभी क्या असली काम करता है

- ✅ फोन के असली Contacts पढ़ना (READ_CONTACTS)
- ✅ Duplicate number check करके साफ़ list दिखाना
- ✅ Call बटन दबाने पर **असली कॉल** लगती है (CALL_PHONE permission के साथ)
- ✅ WhatsApp बटन असली WhatsApp चैट खोलता है
- ✅ Dialer/Keypad से नंबर टाइप करके असली कॉल
- ✅ Settings में 5 Call-Screen toggles (Mute / Speaker / Hold / Keypad / Add Call दिखाना या छुपाना) — SharedPreferences में save होते हैं
- ✅ Custom Incoming Call Screen (ऊपर Caller info, नीचे बड़े Accept/Decline बटन)
- ✅ Custom Active/Ongoing Call Screen (ऊपर Caller+Timer, बीच में Settings के हिसाब से बटन, नीचे End Call)
- ✅ **AdMob Banner Ad** — Contacts list के नीचे, Call/WhatsApp बटनों से दूर (अभी Google का TEST Ad Unit ID लगा है)
- ✅ **Default Phone App बनाने का असली Option** (Settings > "Set" बटन) — RoleManager (Android 10+) या TelecomManager (पुराने Android) के ज़रिए
- ✅ **InCallService** जुड़ा हुआ है — जैसे ही यूज़र इस ऐप को Default Dialer बना देगा, असली Incoming/Active call पर हमारी बनाई हुई Custom Call Screen अपने-आप दिखने लगेगी (system dialer की जगह)

## Play Store पर डालने से पहले ज़रूर बदलें

- `AndroidManifest.xml` में AdMob का TEST App ID → अपने असली AdMob App ID से बदलें
- `AdMobBanner.kt` में TEST Ad Unit ID → अपनी असली Banner Ad Unit ID से बदलें
- App Icon अभी system placeholder है — असली Launcher icon लगाएं

## अभी बाकी है

- Recent Calls (CallLog पढ़ना)
- Add/Edit Contact सेव करना (WRITE_CONTACTS)
- Privacy Mode, Dark Theme, Backup/Restore
- Splash Screen
- Admin Panel (यह अलग backend/web project होगा, इसी APK का हिस्सा नहीं)
- Play Store के लिए Signed Release Build + Privacy Policy + Data Safety form (Contacts/Call permissions के लिए Google को declaration देना ज़रूरी होगा)
