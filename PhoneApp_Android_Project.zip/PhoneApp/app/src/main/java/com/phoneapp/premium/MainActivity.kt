package com.phoneapp.premium

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telecom.Call
import android.telecom.TelecomManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

// ---------- Brand colors (same tokens as the design prototype) ----------
val PremiumBlue = Color(0xFF1652D9)
val CallGreen = Color(0xFF1AA35C)
val WhatsAppGreen = Color(0xFF25D366)
val EndRed = Color(0xFFE5484D)
val FavoriteGold = Color(0xFFE8A93B)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.google.android.gms.ads.MobileAds.initialize(this) {}
        setContent {
            MaterialTheme {
                PhoneAppRoot()
            }
        }
    }
}

/**
 * Places a REAL phone call using Android's telecom system.
 * Needs CALL_PHONE permission granted at runtime (handled by caller).
 */
fun makeRealCall(context: android.content.Context, phone: String) {
    val hasPermission = ContextCompat.checkSelfPermission(
        context, Manifest.permission.CALL_PHONE
    ) == PackageManager.PERMISSION_GRANTED

    val intent = if (hasPermission) {
        Intent(Intent.ACTION_CALL, Uri.parse("tel:$phone"))
    } else {
        // Falls back to opening the dialer with the number filled in;
        // user just has to tap the call button themselves.
        Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
    }
    context.startActivity(intent)
}

/** Opens a REAL WhatsApp chat with this number (official, no fake in-app calling). */
fun openWhatsApp(context: android.content.Context, phone: String) {
    val clean = phone.filter { it.isDigit() || it == '+' }
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$clean"))
    context.startActivity(intent)
}

@Composable
fun PhoneAppRoot() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var contacts by remember { mutableStateOf(listOf<Contact>()) }
    var permissionGranted by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf("contacts") }
    var callSettings by remember { mutableStateOf(CallSettingsStore.load(context)) }
    // Demo/Test call screen state (Settings > Test buttons से चलता है)
    var callScreen by remember { mutableStateOf<Pair<String, Contact>?>(null) }
    var demoMuted by remember { mutableStateOf(false) }
    var demoSpeaker by remember { mutableStateOf(false) }
    var demoHold by remember { mutableStateOf(false) }

    val roleLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { /* result पर कुछ खास करने की ज़रूरत नहीं, Settings उसी वक़्त check कर लेती है */ }

    fun requestDefaultDialer() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(Context.ROLE_SERVICE) as RoleManager
            if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                roleLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER))
            }
        } else {
            val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, context.packageName)
            roleLauncher.launch(intent)
        }
    }

    fun isDefaultDialer(): Boolean {
        val tm = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        return tm.defaultDialerPackage == context.packageName
    }

    fun updateSettings(newSettings: CallScreenSettings) {
        callSettings = newSettings
        CallSettingsStore.save(context, newSettings)
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val readGranted = results[Manifest.permission.READ_CONTACTS] == true
        permissionGranted = readGranted
        if (readGranted) {
            contacts = ContactsRepo.loadContacts(context)
        }
    }

    LaunchedEffect(Unit) {
        val already = ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED

        if (already) {
            permissionGranted = true
            contacts = ContactsRepo.loadContacts(context)
        } else {
            permissionLauncher.launch(
                arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
            )
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == "contacts",
                    onClick = { tab = "contacts" },
                    icon = { Icon(Icons.Filled.Person, contentDescription = "Contacts") },
                    label = { Text("Contacts") }
                )
                NavigationBarItem(
                    selected = tab == "dialer",
                    onClick = { tab = "dialer" },
                    icon = { Icon(Icons.Filled.Dialpad, contentDescription = "Dialer") },
                    label = { Text("Dialer") }
                )
                NavigationBarItem(
                    selected = tab == "favorites",
                    onClick = { tab = "favorites" },
                    icon = { Icon(Icons.Filled.Star, contentDescription = "Favorites") },
                    label = { Text("Favorites") }
                )
                NavigationBarItem(
                    selected = tab == "settings",
                    onClick = { tab = "settings" },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (tab) {
                "dialer" -> DialerScreen()
                "favorites" -> ContactsListScreen(contacts.filter { it.favorite }, modifier = Modifier.fillMaxSize())
                "settings" -> SettingsScreen(
                    settings = callSettings,
                    onSettingsChange = { updateSettings(it) },
                    onTestIncoming = { callScreen = "incoming" to Contact("0", "Hemraj K", "+91 99999 88888") },
                    onTestActive = { callScreen = "active" to Contact("0", "Hemraj K", "+91 99999 88888") },
                    isDefaultDialer = isDefaultDialer(),
                    onMakeDefaultDialer = { requestDefaultDialer() }
                )
                else -> {
                    if (!permissionGranted) {
                        PermissionExplainer {
                            permissionLauncher.launch(
                                arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
                            )
                        }
                    } else {
                        Column(modifier = Modifier.fillMaxSize()) {
                            ContactsListScreen(contacts, modifier = Modifier.weight(1f))
                            AdMobBanner()
                        }
                    }
                }
            }

            // 1) असली Telecom Call को हमेशा priority — जब app Default Dialer हो और असली call आए/जाए
            val realCall = CallManager.currentCall.value
            if (realCall != null) {
                val realState = CallManager.callState.value
                val callerContact = contacts.find {
                    it.phone.filter { d -> d.isDigit() } == CallManager.callerNumber.value.filter { d -> d.isDigit() }
                } ?: Contact("real", CallManager.callerNumber.value.ifEmpty { "Unknown Number" }, CallManager.callerNumber.value)

                if (realState == Call.STATE_RINGING) {
                    IncomingCallScreen(
                        contact = callerContact,
                        settings = callSettings,
                        onAccept = { CallManager.answer() },
                        onDecline = { CallManager.reject() }
                    )
                } else {
                    ActiveCallScreen(
                        contact = callerContact,
                        settings = callSettings,
                        onEndCall = { CallManager.hangUp() },
                        muted = CallManager.isMuted.value,
                        speakerOn = CallManager.isSpeakerOn.value,
                        onHold = realState == Call.STATE_HOLDING,
                        onToggleMute = { CallManager.toggleMute() },
                        onToggleSpeaker = { CallManager.toggleSpeaker() },
                        onToggleHold = { CallManager.toggleHold() }
                    )
                }
            } else {
                // 2) कोई असली call नहीं — Settings के "Test" बटन से demo screen दिखाओ
                callScreen?.let { (phase, contact) ->
                    when (phase) {
                        "incoming" -> IncomingCallScreen(
                            contact = contact,
                            settings = callSettings,
                            onAccept = { callScreen = "active" to contact },
                            onDecline = { callScreen = null }
                        )
                        "active" -> ActiveCallScreen(
                            contact = contact,
                            settings = callSettings,
                            onEndCall = { callScreen = null },
                            muted = demoMuted,
                            speakerOn = demoSpeaker,
                            onHold = demoHold,
                            onToggleMute = { demoMuted = !demoMuted },
                            onToggleSpeaker = { demoSpeaker = !demoSpeaker },
                            onToggleHold = { demoHold = !demoHold }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionExplainer(onRequest: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.Contacts, contentDescription = null, modifier = Modifier.size(56.dp), tint = PremiumBlue)
        Spacer(Modifier.height(16.dp))
        Text(
            "आपके फोन में सेव Contacts को इस ऐप में दिखाने के लिए अनुमति दें।",
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = onRequest, colors = ButtonDefaults.buttonColors(containerColor = PremiumBlue)) {
            Text("अनुमति दें")
        }
    }
}

@Composable
fun ContactsListScreen(contacts: List<Contact>, modifier: Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Column(modifier = modifier.fillMaxWidth().padding(16.dp)) {
        Text("Contacts", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (contacts.isEmpty()) {
            Text("कोई Contact नहीं मिला।")
        } else {
            LazyColumn {
                items(contacts) { contact ->
                    ContactRow(
                        contact = contact,
                        onCall = { makeRealCall(context, contact.phone) },
                        onWhatsApp = { openWhatsApp(context, contact.phone) }
                    )
                    Divider()
                }
            }
        }
    }
}

@Composable
fun ContactRow(contact: Contact, onCall: () -> Unit, onWhatsApp: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(44.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.AccountCircle, contentDescription = null, tint = PremiumBlue, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(contact.name, fontWeight = FontWeight.Medium)
            Text(contact.phone, fontSize = 13.sp, color = Color.Gray)
        }
        IconButton(onClick = onCall) {
            Icon(Icons.Filled.Call, contentDescription = "Call", tint = CallGreen)
        }
        IconButton(onClick = onWhatsApp) {
            Icon(Icons.Filled.Chat, contentDescription = "WhatsApp", tint = WhatsAppGreen)
        }
    }
}

@Composable
fun SettingsScreen(
    settings: CallScreenSettings,
    onSettingsChange: (CallScreenSettings) -> Unit,
    onTestIncoming: () -> Unit,
    onTestActive: () -> Unit,
    isDefaultDialer: Boolean,
    onMakeDefaultDialer: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        Text("PHONE", fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Default Phone App")
                Text(
                    if (isDefaultDialer) "यह ऐप अभी Default Dialer है ✅" else "अभी System Dialer इस्तेमाल हो रहा है",
                    fontSize = 12.sp, color = Color.Gray
                )
            }
            if (!isDefaultDialer) {
                Button(onClick = onMakeDefaultDialer, colors = ButtonDefaults.buttonColors(containerColor = PremiumBlue)) {
                    Text("Set")
                }
            }
        }
        Divider()

        Spacer(Modifier.height(20.dp))
        Text("CALL SCREEN", fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))

        SettingToggleRow("Mute button दिखाएं", settings.showMute) {
            onSettingsChange(settings.copy(showMute = it))
        }
        SettingToggleRow("Speaker button दिखाएं", settings.showSpeaker) {
            onSettingsChange(settings.copy(showSpeaker = it))
        }
        SettingToggleRow("Hold button दिखाएं", settings.showHold) {
            onSettingsChange(settings.copy(showHold = it))
        }
        SettingToggleRow("Keypad button दिखाएं (in-call)", settings.showKeypad) {
            onSettingsChange(settings.copy(showKeypad = it))
        }
        SettingToggleRow("Add Call button दिखाएं", settings.showAddCall) {
            onSettingsChange(settings.copy(showAddCall = it))
        }

        Spacer(Modifier.height(24.dp))
        Text("PREVIEW", fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onTestIncoming, modifier = Modifier.fillMaxWidth()) {
            Text("▶ Test Incoming Call Screen")
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onTestActive, modifier = Modifier.fillMaxWidth()) {
            Text("▶ Test Active Call Screen")
        }
    }
}

@Composable
fun SettingToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
    Divider()
}

/**
 * Incoming Call Screen:
 * ऊपर -> Caller की Photo/Name/Number
 * नीचे -> Decline (लाल) और Accept (हरा) साफ़ अलग-अलग बड़े बटन
 */
@Composable
fun IncomingCallScreen(
    contact: Contact,
    settings: CallScreenSettings,
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
    ) {
        // ऊपर वाला हिस्सा: Caller जानकारी
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(top = 64.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Incoming call", color = Color.Gray, fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))
            Icon(Icons.Filled.AccountCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(100.dp))
            Spacer(Modifier.height(10.dp))
            Text(contact.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(contact.phone, color = Color.Gray, fontSize = 14.sp)
        }

        // नीचे वाला हिस्सा: Accept / Decline
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 56.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                FloatingActionButton(onClick = onDecline, containerColor = EndRed, modifier = Modifier.size(64.dp)) {
                    Icon(Icons.Filled.CallEnd, contentDescription = "Decline", tint = Color.White)
                }
                Spacer(Modifier.height(6.dp))
                Text("Decline", color = Color.Gray, fontSize = 12.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                FloatingActionButton(onClick = onAccept, containerColor = CallGreen, modifier = Modifier.size(64.dp)) {
                    Icon(Icons.Filled.Call, contentDescription = "Accept", tint = Color.White)
                }
                Spacer(Modifier.height(6.dp))
                Text("Accept", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}

/**
 * Active (ongoing) Call Screen:
 * ऊपर -> Caller जानकारी + टाइमर
 * बीच -> Mute/Speaker/Hold/Keypad/Add Call (Settings के हिसाब से दिखें/छुपें)
 * नीचे -> End Call
 */
@Composable
fun ActiveCallScreen(
    contact: Contact,
    settings: CallScreenSettings,
    onEndCall: () -> Unit,
    muted: Boolean,
    speakerOn: Boolean,
    onHold: Boolean,
    onToggleMute: () -> Unit,
    onToggleSpeaker: () -> Unit,
    onToggleHold: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(top = 56.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(if (onHold) "On hold" else "Ongoing call", color = Color.Gray, fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))
            Icon(Icons.Filled.AccountCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(100.dp))
            Spacer(Modifier.height(10.dp))
            Text(contact.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(contact.phone, color = Color.Gray, fontSize = 14.sp)
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 48.dp, start = 32.dp, end = 32.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                if (settings.showMute) {
                    CallOptionButton(
                        icon = if (muted) Icons.Filled.MicOff else Icons.Filled.Mic,
                        label = "Mute",
                        active = muted,
                        onClick = onToggleMute
                    )
                }
                if (settings.showSpeaker) {
                    CallOptionButton(
                        icon = Icons.Filled.VolumeUp,
                        label = "Speaker",
                        active = speakerOn,
                        onClick = onToggleSpeaker
                    )
                }
                if (settings.showHold) {
                    CallOptionButton(
                        icon = Icons.Filled.PauseCircle,
                        label = "Hold",
                        active = onHold,
                        onClick = onToggleHold
                    )
                }
                if (settings.showKeypad) {
                    CallOptionButton(
                        icon = Icons.Filled.Dialpad,
                        label = "Keypad",
                        active = false,
                        onClick = { }
                    )
                }
                if (settings.showAddCall) {
                    CallOptionButton(
                        icon = Icons.Filled.PersonAdd,
                        label = "Add",
                        active = false,
                        onClick = { }
                    )
                }
            }
            Spacer(Modifier.height(32.dp))
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                FloatingActionButton(onClick = onEndCall, containerColor = EndRed, modifier = Modifier.size(64.dp)) {
                    Icon(Icons.Filled.CallEnd, contentDescription = "End call", tint = Color.White)
                }
            }
        }
    }
}

@Composable
fun CallOptionButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
            onClick = onClick,
            modifier = Modifier
                .size(48.dp)
                .background(if (active) PremiumBlue else Color(0xFF1E2433), shape = androidx.compose.foundation.shape.CircleShape)
        ) {
            Icon(icon, contentDescription = label, tint = Color.White)
        }
        Spacer(Modifier.height(4.dp))
        Text(label, color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun DialerScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var number by remember { mutableStateOf("") }
    val keys = listOf(
        "1", "2", "3",
        "4", "5", "6",
        "7", "8", "9",
        "*", "0", "#"
    )

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(20.dp))
        Text(number.ifEmpty { " " }, fontSize = 28.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(24.dp))

        for (row in keys.chunked(3)) {
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                for (key in row) {
                    OutlinedButton(
                        onClick = { number += key },
                        shape = androidx.compose.foundation.shape.CircleShape,
                        modifier = Modifier.size(72.dp)
                    ) {
                        Text(key, fontSize = 22.sp)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }

        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            FloatingActionButton(
                onClick = { if (number.isNotEmpty()) makeRealCall(context, number) },
                containerColor = CallGreen
            ) {
                Icon(Icons.Filled.Call, contentDescription = "Call", tint = Color.White)
            }
            Spacer(Modifier.width(20.dp))
            IconButton(onClick = { if (number.isNotEmpty()) number = number.dropLast(1) }) {
                Icon(Icons.Filled.Backspace, contentDescription = "Backspace")
            }
        }
    }
}
