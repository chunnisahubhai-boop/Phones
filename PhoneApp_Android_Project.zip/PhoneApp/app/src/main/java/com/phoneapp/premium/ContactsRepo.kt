package com.phoneapp.premium

import android.content.Context
import android.provider.ContactsContract

data class Contact(
    val id: String,
    val name: String,
    val phone: String,
    val favorite: Boolean = false
)

/**
 * Reads REAL contacts from the phone's Contacts Provider.
 * Requires READ_CONTACTS permission to be granted first.
 */
object ContactsRepo {

    fun loadContacts(context: Context): List<Contact> {
        val result = mutableListOf<Contact>()
        val seenNumbers = mutableSetOf<String>()

        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.STARRED
        )

        context.contentResolver.query(
            uri, projection, null, null,
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
        )?.use { cursor ->
            val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val starIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.STARRED)

            while (cursor.moveToNext()) {
                val id = cursor.getString(idIdx) ?: continue
                val name = cursor.getString(nameIdx) ?: "Unknown"
                val number = cursor.getString(numberIdx)?.replace(" ", "") ?: continue
                val starred = starIdx >= 0 && cursor.getInt(starIdx) == 1

                // Duplicate number check, as requested in the spec
                if (seenNumbers.contains(number)) continue
                seenNumbers.add(number)

                result.add(Contact(id = id, name = name, phone = number, favorite = starred))
            }
        }
        return result
    }
}
