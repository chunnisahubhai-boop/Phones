package com.phoneapp.premium

import android.telecom.Call
import android.telecom.InCallService

/**
 * यह Service Android का Telecom framework तभी चलाता है जब यह ऐप
 * Default Phone/Dialer App बनाया जाता है (Settings > Make Default Phone App)।
 *
 * असली incoming/outgoing call आते ही onCallAdded() अपने आप कॉल हो जाता है,
 * और हमारा Compose UI (IncomingCallScreen/ActiveCallScreen) उसी असली Call
 * से जुड़ जाता है — CallManager के ज़रिए।
 */
class InCallServiceImpl : InCallService() {

    override fun onCreate() {
        super.onCreate()
        CallManager.serviceRef = this
    }

    override fun onDestroy() {
        super.onDestroy()
        CallManager.serviceRef = null
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.attach(call)
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        CallManager.detach(call)
    }
}
