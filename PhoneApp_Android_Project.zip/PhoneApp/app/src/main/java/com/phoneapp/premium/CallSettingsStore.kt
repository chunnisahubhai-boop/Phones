package com.phoneapp.premium

import android.content.Context

data class CallScreenSettings(
    val showMute: Boolean = true,
    val showSpeaker: Boolean = true,
    val showHold: Boolean = true,
    val showKeypad: Boolean = true,
    val showAddCall: Boolean = false
)

/** Simple persisted store so toggles survive app restart. */
object CallSettingsStore {
    private const val PREFS = "call_screen_settings"

    fun load(context: Context): CallScreenSettings {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return CallScreenSettings(
            showMute = p.getBoolean("showMute", true),
            showSpeaker = p.getBoolean("showSpeaker", true),
            showHold = p.getBoolean("showHold", true),
            showKeypad = p.getBoolean("showKeypad", true),
            showAddCall = p.getBoolean("showAddCall", false)
        )
    }

    fun save(context: Context, settings: CallScreenSettings) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("showMute", settings.showMute)
            .putBoolean("showSpeaker", settings.showSpeaker)
            .putBoolean("showHold", settings.showHold)
            .putBoolean("showKeypad", settings.showKeypad)
            .putBoolean("showAddCall", settings.showAddCall)
            .apply()
    }
}
