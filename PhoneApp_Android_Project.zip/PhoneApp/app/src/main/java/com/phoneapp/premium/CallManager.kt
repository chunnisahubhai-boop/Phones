package com.phoneapp.premium

import android.telecom.Call
import android.telecom.CallAudioState
import androidx.compose.runtime.mutableStateOf

/**
 * असली Telecom Call की state रखता है और Compose UI को update करता है।
 * InCallServiceImpl इसे भरता है जब असली कॉल आती/जाती है।
 */
object CallManager {
    var currentCall = mutableStateOf<Call?>(null)
    var callState = mutableStateOf(Call.STATE_DISCONNECTED)
    var callerNumber = mutableStateOf("")
    var isMuted = mutableStateOf(false)
    var isSpeakerOn = mutableStateOf(false)

    // Service reference ताकि mute/speaker जैसे audio controls लगा सकें
    var serviceRef: InCallServiceImpl? = null

    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            callState.value = state
        }
    }

    fun attach(call: Call) {
        currentCall.value = call
        callerNumber.value = call.details?.handle?.schemeSpecificPart ?: ""
        callState.value = call.state
        call.registerCallback(callback)
    }

    fun detach(call: Call) {
        call.unregisterCallback(callback)
        currentCall.value = null
        callState.value = Call.STATE_DISCONNECTED
        isMuted.value = false
        isSpeakerOn.value = false
    }

    fun answer() = currentCall.value?.answer(0)
    fun reject() = currentCall.value?.reject(false, null)
    fun hangUp() = currentCall.value?.disconnect()

    fun toggleHold() {
        val c = currentCall.value ?: return
        if (c.state == Call.STATE_HOLDING) c.unhold() else c.hold()
    }

    fun toggleMute() {
        isMuted.value = !isMuted.value
        serviceRef?.setMuted(isMuted.value)
    }

    fun toggleSpeaker() {
        isSpeakerOn.value = !isSpeakerOn.value
        val route = if (isSpeakerOn.value) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE
        serviceRef?.setAudioRoute(route)
    }
}
